package com.example.flashlight

import android.content.Context


class Torch (context: Context) {
    private var cameraId: String? = null
    private val 




}//class